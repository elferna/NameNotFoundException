package clue.game.model;

public class Room {

	public void addPlayer(Player player) {
		// TODO Auto-generated method stub
		
	}

	public void removePlayer(Player player) {
		// TODO Auto-generated method stub
		
	}

	public Object getXPos() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getYPos() {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean isHallway() {
		// TODO Auto-generated method stub
		return false;
	}

}
