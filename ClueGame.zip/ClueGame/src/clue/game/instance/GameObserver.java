package clue.game.instance;

import clue.game.model.Card;

public interface GameObserver {

	public void onGameStart();
	
	public void onPlayerMove();
	
	public void onMapChange();

	public void onSuggestion(String message);

	public void onTurnChange();

	public void onAccusation(String message);
	
}
