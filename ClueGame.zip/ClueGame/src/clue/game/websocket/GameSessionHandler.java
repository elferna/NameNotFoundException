package clue.game.websocket;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.enterprise.context.ApplicationScoped;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.spi.JsonProvider;
import javax.websocket.Session;

import clue.game.instance.GameObserver;
import clue.game.model.Card;
import clue.game.model.Player;
import clue.game.model.Position;

@ApplicationScoped
public class GameSessionHandler implements GameObserver{
	private int deviceId = 0;
//	private Set<GameSession> gameSessions = Collections.synchronizedSet(new HashSet<>());
	private GameSession gameSession;
//	private Map<Session, Player> connectedPlayers = Collections.synchronizedMap(new HashMap<>());
	
	//Constructor with given names, this is just to try the concept
	public GameSessionHandler(){
		gameSession = new GameSession();
		gameSession.setBoardGameObserver(this);
	}
	
	// This add a session depending on how many users. For now,
	// we're assuming only one game session exists for the sake
	// of time.
	public synchronized void addSession(Session session){
		
		this.gameSession.getPlayersSessions().add(session);
		
		this.gameSession.addPlayer(new Player("P".concat(gameSession.getPlayerCount().toString()), session));
		
		for(Player p : gameSession.getAllBoardGamePlayers()) {
			System.out.println("%%%%%%%%%%%%%%%%%%%%% " + p.getPlayerName() + " %%%%%%%%%%%%%%%%%%%%%");
		}
		
		for(Player player : gameSession.getAllBoardGamePlayers()) {
			this.sendToAllConnectedSessions(this.createChatMessage("Online: " + player.getPlayerName()));
		}
		
		this.sendPlayerName(session);
		this.getGameStatus();
	}
	
	public void removeSession(Session session){
		this.gameSession.getPlayersSessions().remove(session);
	}
	
	//Function to broadcast the message from the chat to all users
	public void broadcastMsg(Session session, String message){
		//Creates a messages String from the message taken from the chat
	    String tempMessageWithName = "";
	    
	    System.out.println("Broadcasting Message: " + message);
	    System.out.println("Session: " + session.getId());	    
	    
		for(Player player : this.gameSession.getAllBoardGamePlayers()){
			if(player.getId() == session.getId()){
				tempMessageWithName = player.getPlayerName() + " : " + message;
			}
		}
		
		//Creates JSON object and send
		JsonObject tempMessage = createChatMessage(tempMessageWithName);
		sendToAllConnectedSessions(tempMessage);
	}
	
	private JsonObject createNotificationMessage(String notificationMessage) {
    	
        JsonProvider provider = JsonProvider.provider();
        JsonObject tempMessage = provider.createObjectBuilder()
                .add("type", "displayOnGameNotificationArea")
                .add("message", notificationMessage)
                .build();
        
        return tempMessage;
    }
	
	private JsonObject createPopUpMessage(String notificationMessage) {
    	
        JsonProvider provider = JsonProvider.provider();
        JsonObject tempMessage = provider.createObjectBuilder()
                .add("type", "popUpNotification")
                .add("message", notificationMessage)
                .build();
        
        return tempMessage;
    }
    
    private JsonObject createChatMessage(String chatMessage) {
    	System.out.println(chatMessage);
        JsonProvider provider = JsonProvider.provider();
        JsonObject tempMessage = provider.createObjectBuilder()
                .add("type", "chat")
                .add("message", chatMessage)
                .build();
        return tempMessage;
    }


    private void sendToAllConnectedSessions(JsonObject message) {
        for (Session session : this.gameSession.getPlayersSessions()) {
            sendToSession(session, message);
        }
        
        System.out.println("Outgoing message: " + message);
    }
    
    private void sendToAllOtherSessions(Session session, JsonObject message) {
        for (Session tempSession : this.gameSession.getPlayersSessions()) {
        	if(tempSession.getId() != session.getId()){
        		sendToSession(session, message);
        	}
        }
        
        System.out.println("Outgoing message: " + message);
    }

    private void sendToSession(Session session, JsonObject message) {
        try {
            session.getBasicRemote().sendText(message.toString());
        } catch (IOException ex) {
        	this.gameSession.getPlayersSessions().remove(session);
            Logger.getLogger(GameSessionHandler.class.getName()).log(Level.SEVERE,null, ex);
        }
    }
    
    public JsonObject createPlayerPositionJsonMessage(Player player){
    	
    	System.out.println("Generating player position binary map: " + player.getPlayerName());
    	
    	System.out.println((player.getPlayerCharacter() != null) ? "Player Character is defined." : "No funciona :(.");
    	
    	JsonProvider provider = JsonProvider.provider();
    	JsonObject tempMessage = provider.createObjectBuilder()
                 .add("name", player.getPlayerName())
                 .add("positionMap", player.getPlayerCharacter().getBinaryPositionMap())
                 .build();
        
        return tempMessage;
    }

	public void sendPlayersPositionMap() {
		
		JsonArrayBuilder jsonArrayBuilder = Json.createArrayBuilder();
		
		for(Player player : this.gameSession.getAllBoardGamePlayers()){
			System.out.println("Player " + player.getPlayerName() + " position map generated...");
			jsonArrayBuilder.add(this.createPlayerPositionJsonMessage(player));
		}
		
		JsonProvider provider = JsonProvider.provider();
		JsonObject tempMessage = provider.createObjectBuilder()
                .add("type", "requestPlayersPositionMap")
                .add("players", jsonArrayBuilder)
                .build();
		
		this.sendToAllConnectedSessions(tempMessage);
	}

	public void initializeBoardGame() {
		this.gameSession.startGame();
		
		JsonProvider provider = JsonProvider.provider();
		JsonObject tempMessage = provider.createObjectBuilder()
                .add("type", "startGame")
                .build();
		
		this.sendToAllConnectedSessions(tempMessage);
	}

	public void getGameStatus() {
		
		JsonProvider provider = JsonProvider.provider();
		JsonObjectBuilder tempMessage = provider.createObjectBuilder()
                .add("type", "gameStatus")
                .add("numberOfPlayers", this.gameSession.getAllBoardGamePlayers().size())
                .add("gameStartTimeout", "");
		
		if(this.gameSession.getBoardGameTurn() != null){
			tempMessage.add("boardGameTurn", this.gameSession.getBoardGameTurn().getPlayerName());
		}
		else{
			tempMessage.add("boardGameTurn", "?");
		}
		
		this.sendToAllConnectedSessions(tempMessage.build());
		
	}
	
	public void sendPlayerName(Session session) {
		
		String playerName = "";
		
		for(Player player : this.gameSession.getAllBoardGamePlayers()){
			if(player.getId() == session.getId()){
				playerName = player.getPlayerName();
			}
		}
		
		JsonProvider provider = JsonProvider.provider();
		JsonObject tempMessage = provider.createObjectBuilder()
                .add("type", "playerName")
                .add("playerName", playerName)
                .build();
		
		this.sendToSession(session, tempMessage);
		
	}
	
	public void sendPlayersCards(){
		
		JsonArrayBuilder jsonArrayBuilder = Json.createArrayBuilder();
		ArrayList<Card> cardNames = new ArrayList<Card>();
		
		for(Player player : this.gameSession.getAllBoardGamePlayers()){
				cardNames = player.getHand();
				
				for(int i = 0; i < cardNames.size(); i++ ){
					jsonArrayBuilder.add(cardNames.get(i).filePath);
					//fileNames[i] = cardNames.get(i).filePath;
				}
				
				JsonProvider provider = JsonProvider.provider();
				JsonObject tempMessage = provider.createObjectBuilder()
						.add("type", "playerCards")
						.add("cardNames", jsonArrayBuilder)
						.build();
				
				for (Session session : this.gameSession.getPlayersSessions()) {
					if(session.getId() == player.getId()){
						this.sendToSession(session, tempMessage);
					}
				}
		
		}
	}

	public void movePlayer(Session session, String posX, String posY) {
		
		if(doesSessionMatchPlayerInTurn(session, this.gameSession.getBoardGameTurn())){
			if(!this.gameSession.getBoardGameTurn().hasMove()){
		
				this.gameSession.setPlayerPosition(session, new Position(Integer.parseInt(posX),Integer.parseInt(posY)));
		
				for(Player player : this.gameSession.getAllBoardGamePlayers()){
					if(player.getId() == session.getId()){
						this.sendPlayersPositionMap();
					}
				}
			}
		}
		
	}

	@Override
	public void onGameStart() {
		this.sendPlayersPositionMap();
		this.sendPlayersCards();
		this.sendCurrentPlayerTurnNotification(this.gameSession.getBoardGameTurn());
		this.getGameStatus();
	}
	
	public void sendCurrentPlayerTurnNotification(Player player){
		this.sendToAllConnectedSessions(this.createNotificationMessage(player.getPlayerName() + " - Plays now!"));
	}

	@Override
	public void onPlayerMove(){
		this.sendPlayersPositionMap();
	}

	@Override
	public void onMapChange() {
		this.sendPlayersPositionMap();
	}

	public void acussationAction(Session session, String who, String what, String where) {
		if(doesSessionMatchPlayerInTurn(session, this.gameSession.getBoardGameTurn())){
			
			if(this.gameSession.getBoardGameTurn().hasMove() &&
					!this.gameSession.getBoardGameTurn().hasMadeAccusation()){
				// Something here...notify board game. Remember to update HasAccusation()...
				this.gameSession.makeAccusation(who, what, where);
				this.broadcastAccusation(session, who, what, where);
			}
		}
	}

	public void suggestionAction(Session session, String who, String what, String where) {
		if(doesSessionMatchPlayerInTurn(session, this.gameSession.getBoardGameTurn())){
			
			if(this.gameSession.getBoardGameTurn().hasMove() &&
					!this.gameSession.getBoardGameTurn().hasMadeAccusation()){
				// Something here...notify board game. Remember to update HasAccusation()...
				this.gameSession.makeSuggestion(who, what, where);
				this.broadcastAccusation(session, who, what, where);
			}
		}
	}
	
	public boolean doesSessionMatchPlayerInTurn(Session session, Player player){
		
		boolean tempBoolean = false;
		if(player.getId() == session.getId()){
			tempBoolean = true;
		}
		return tempBoolean;
	}
	
	public void broadcastAccusation(Session session, String who, String what, String where){
		String playerName = "";
		
		for(Player player : this.gameSession.getAllBoardGamePlayers()){
			if(player.getId() == session.getId()){
				playerName = player.getPlayerName();
			}
		}
		
		String notificationMessage = playerName + " - Who: " + who + " What: " + what + " Where: " + where;
		
		this.sendToAllConnectedSessions(this.createNotificationMessage(notificationMessage));
	}
	
	public Session getSessionFromId(String id){
		for(Session session : this.gameSession.getPlayersSessions()){
			if(id == session.getId()){
				return session;
			}
		}
		return null;
	}

	@Override
	public void onSuggestion(String message) {
		this.sendToSession(this.getSessionFromId(this.gameSession.getBoardGameTurn().getId()),
							this.createPopUpMessage(message));
	}

	@Override
	public void onTurnChange() {
		this.getGameStatus();
	}

	@Override
	public void onAccusation(String message) {
		this.sendToAllConnectedSessions(this.createNotificationMessage(message));
		this.sendToSession(this.getSessionFromId(this.gameSession.getBoardGameTurn().getId()),
				this.createPopUpMessage(message));
	}
	
}
