package clue.game.websocket;

import java.util.ArrayList;

/**
 * Represents a game that a group of players belong to.
 * 
 * @author Amanda
 *
 */

import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.Stack;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.json.JsonValue;
import javax.websocket.Session;

import clue.game.instance.GameObserver;
import clue.game.model.BoardGame;
import clue.game.model.Player;
import clue.game.model.Position;

public class GameSession {

	private final Set<Player> players = new HashSet<>();
	private final Set<Session> playersSessions = new HashSet<>();
	private final int PLAYER_LIMIT  = 6;
	private Integer playerCount = 0;
	private Stack<String> suspectsArray = new Stack<String>();
	private BoardGame boardGame;

	public Set<Session> getPlayersSessions() {
		return this.playersSessions;
	}

	/**
	 * Constructor
	 */
	public GameSession() {
		this.suspectsArray.push("Mustard");
		this.suspectsArray.push("White");
		this.suspectsArray.push("Green");
		this.suspectsArray.push("Yellow");
		this.suspectsArray.push("Red");
		this.suspectsArray.push("Pink");	
		
		this.boardGame = new BoardGame(generateBoardGameID());
	}

	public void addPlayer(Player player) {
		
		// If there are less than 6 players in the
		// game session and the player is not already
		// in the session, add the player
		if(players.size() <= PLAYER_LIMIT && !players.contains(player)) {
			
			// Assign the player the next available suspect
			player.setPlayerCharacter(this.suspectsArray.pop());
			
			// Add the player to the game and update the count
			players.add(player);
			this.boardGame.addPlayer(player);
			playerCount++;
			
		}
		
	}
	
	public Set<Player> getAllPlayers() {
		return players;
	}
	
	public void removePlayer(Player player) {
		this.suspectsArray.push(player.getPlayerName());
		players.remove(player);
	}

	/**
	 * @return the playerCount
	 */
	public Integer getPlayerCount() {
		return playerCount;
	}	
	
	/**
	 * Starts the game. Need someplace to call this...
	 */
	public void startGame() {
		System.out.println("Starting Game...SERVER");
		
		System.out.println("Players size: " + players.size());
		for(Player tempPlayer: players){
			System.out.println(tempPlayer);
		}
		
		this.boardGame.initializeGame(new ArrayList<Player>(getAllPlayers()));
				
		System.out.println("Game Started...SERVER");
	}
	/**
	 * Generates an ID for the game board instance
	 * @return
	 */
	private String generateBoardGameID() {
		String resultId = "";
		Random coinToss = new Random();
		Random chooseLetter = new Random();
		Random chooseNum = new Random();
		
		String alphabet[] = {"a", "b", "c", "d", "e", "f", "g",
		                     "h", "i", "j", "k", "l", "m", "n",
		                     "o", "p", "q", "r", "s", "t", "u",
		                     "v", "w", "x", "y", "z"};
		String numbers[] = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0"};
		
		for(int i=0; i < 20; i++) {
			
			if(coinToss.nextInt(2) == 0) {
				resultId = resultId.concat(alphabet[chooseLetter.nextInt(26)]);
			}
			
			else if (coinToss.nextInt(2) == 1) {
				resultId = resultId.concat(numbers[chooseNum.nextInt(10)]);
			}
		}
		return resultId;
	}

	public String getGameStartTimeout() {
		return "Unimplemented";
	}

	public Player getBoardGameTurn() {
		return this.boardGame.getCurrentTurn();
	}

	public void setPlayerPosition(Session session, Position position) {
		this.boardGame.movePlayer(session,position);
	}
	
	public ArrayList<Player> getAllBoardGamePlayers(){
		return this.boardGame.allPlayers;
	}
	
	public void setBoardGameObserver(GameObserver observer){
		this.boardGame.setGameObserver(observer);
	}

	public void makeSuggestion(String who, String what, String where) {
		this.boardGame.makeSuggestion(who,what,where);
	}
	
	public boolean getIsCurrentPlayerOnHallway(){
		return this.getIsCurrentPlayerOnHallway();
	}

	public void makeAccusation(String who, String what, String where) {
		// TODO Auto-generated method stub
		this.boardGame.makeAccusation(who,what,where);
	}
}
