package clue.game.model;

import java.util.*;
import javax.swing.JOptionPane;
import javax.websocket.Session;

import clue.game.model.Player;
import clue.game.model.Position;
import clue.game.instance.GameObserver;
import clue.game.model.Card;
import clue.game.model.Solution;
import jersey.repackaged.com.google.common.collect.Lists;

public class BoardGame {

	public ArrayList<Player>allPlayers = new ArrayList<>();
	private ArrayList<Card>roomCards = new ArrayList<>();  
	private ArrayList<Card>weaponCards = new ArrayList<>();
    private ArrayList<Card>suspectCards = new ArrayList<>(); 
    private ArrayList<GameObserver> gameObservers = new ArrayList<>(); 
    private String[] boundaryMap = null;
    public enum Cards{ Room, Suspect, Weapon};
    String gameID;
    private int[][] location;
    Solution answer;
    private boolean isGameStarted = false;
    
    Player currentPlayerOnTurn = null;
    Queue<Player> playerTurnCollection = new LinkedList<Player>();
	
	private ArrayList<String> yesAndNo;
 
	public BoardGame(ArrayList<Player> allPlayers, String gameID) {
		this.allPlayers = allPlayers;
		this.gameID = gameID;
		this.location = new int[7][7];
		this.roomCards = new ArrayList<Card>();  
		this.weaponCards = new ArrayList<Card>();
	    this.suspectCards = new ArrayList<Card>();
		this.yesAndNo = new ArrayList<String>();
            this.yesAndNo.add("yes");
            this.yesAndNo.add("no");
	}
	
	public BoardGame(String gameID) {
		this.gameID = gameID;
		this.location = new int[7][7];
		this.roomCards = new ArrayList<Card>();  
		this.weaponCards = new ArrayList<Card>();
	    this.suspectCards = new ArrayList<Card>();
		this.yesAndNo = new ArrayList<String>();
            this.yesAndNo.add("yes");
            this.yesAndNo.add("no");
        this.initializeBoundaryMap();
	}
	
	private void initializeBoundaryMap(){
		boundaryMap = new String[]{"0000100",
							   	   "0111110",
							   	   "1101011",
							   	   "0111110",
							   	   "1101010",
							   	   "0111110",
							   	   "0010100"};
	}
	
	public BoardGame() {
		
	}
	
	public void setGameObserver(GameObserver observer){
		this.gameObservers.add(observer);
	}
	
	//Initializations
	public void initializeRooms()
	{
		this.roomCards.add(new Card("Study" ,1,5,"Study.jpg", 'R'));
		this.roomCards.add(new Card("Hall" ,3,5,"Hall.jpg", 'R'));
		this.roomCards.add(new Card("Lounge" ,5,5,"Lounge.jpg", 'R'));
	       
		this.roomCards.add(new Card("Library" ,1,3,"Library.jpg", 'R'));
		this.roomCards.add(new Card("Billard Room" ,3,3,"Billard Room.jpg", 'R'));
		this.roomCards.add(new Card("Dining Room" ,5,3,"Dining Room.jpg", 'R'));
	       
		this.roomCards.add(new Card("Conservatory" ,1,1,"Conservatory.jpg", 'R'));
		this.roomCards.add(new Card("Ballroom" ,3,1,"Ballroom.jpg", 'R'));
		this.roomCards.add(new Card("Kitchen" ,5,1,"Kitchen.jpg", 'R'));
	    Collections.shuffle(this.roomCards);

	}
	public void initializeHallways()
	{		   
		this.roomCards.add(new Card("hallway1" ,2,5,"//room", 'R'));
		this.roomCards.add(new Card("hallway2" ,4,5,"//room", 'R'));
		   
		this.roomCards.add(new Card("hallway3" ,1,4,"//room", 'R'));
		this.roomCards.add(new Card("hallway4" ,3,4,"//room", 'R'));
		this.roomCards.add(new Card("hallway5" ,5,4,"//room", 'R'));
		
		this. roomCards.add(new Card("hallway6" ,2,3,"//room", 'R'));
		this.roomCards.add(new Card("hallway7" ,4,3,"//room", 'R'));
		   
		this.roomCards.add(new Card("hallway8" ,1,2,"//room", 'R'));
		this.roomCards.add(new Card("hallway9" ,3,2,"//room", 'R'));
		this.roomCards.add(new Card("hallway10" ,5,2,"//room", 'R'));
		
		this.roomCards.add(new Card("hallway11" ,2,1,"//room", 'R'));
		this.roomCards.add(new Card("hallway12" ,4,1,"//room", 'R'));
		Collections.shuffle(this.roomCards);
	}
	public void initializeWeapons()
	{
		this.weaponCards.add(new Card( "Rope", "Rope.jpg", 'W'));
		this.weaponCards.add(new Card( "Lead Pipe", "Lead Pipe.jpg", 'W'));
		this.weaponCards.add(new Card( "Knife", "Knife.jpg", 'W'));
		this.weaponCards.add(new Card( "Wrench", "Wrench.jpg", 'W'));
		this.weaponCards.add(new Card( "Candlestick", "Candlestick.jpg", 'W'));
		this.weaponCards.add(new Card( "Revolver", "Revolver.jpg", 'W'));
		Collections.shuffle(weaponCards);
    
	}
	public void randomlyPlaceWeapons(){
		
       for (int i=0; i<weaponCards.size(); i++) /*randomize room distribution*/
       {
    	   Card randomRoom = this.roomCards.get(i);
    	   this.weaponCards.get(i).setX(randomRoom.getX());
    	   this.weaponCards.get(i).setY(randomRoom.getY()); 
       }
	}
	public void  initializeSuspects()
	{
		this.suspectCards.add(new Card( "Scarlet",4,6, "Miss Scarlet.jpg", 'C'));
		this.suspectCards.add(new Card( "Mustard",6,2, "Mustard.jpg", 'C'));
		this.suspectCards.add(new Card( "White",4,0, "Mrs. White.jpg", 'C'));
		this.suspectCards.add(new Card( "Green",2,6, "Green.jpg", 'C'));
		this.suspectCards.add(new Card( "Peacock",0,2, "Mrs Peacock.jpg", 'C'));
		this.suspectCards.add(new Card( "Plum",0,4, "Plum.jpg", 'C')); 
		//Collections.shuffle(this.suspectCards);
	       
	}
	public void initializeGame(ArrayList<Player> players)
	{	   
		this.allPlayers = players;
		this.playerTurnCollection.addAll(this.allPlayers);
		initializeRooms();  
		initializeWeapons();
		randomlyPlaceWeapons();
	    initializeSuspects();
	    chooseAnAvatar();

	    this.answer = new Solution(this.suspectCards.remove(0),this.roomCards.remove(0), this.weaponCards.remove(0));
	    
	    System.out.println("Winning solution - Who: " + this.answer.getPerson() + " What: " +  this.answer.getWeapon() + " Where: "  + this.answer.getPlace());
	    
	    ArrayList<Card>allCards = new ArrayList<Card>();
        allCards.addAll(this.suspectCards);
        allCards.addAll(this.weaponCards);
        allCards.addAll(this.roomCards); 
        Collections.shuffle(allCards);
	    dealCards(allCards,players);
	    
	    initializeHallways();//rooms and hallways are separated for distribution of 
	    
	    this.suspectCards.add(answer.Person);
	    this.roomCards.add(answer.Place);
	    this.weaponCards.add(answer.Weapon);
	    
	    this.isGameStarted = true;
	    this.getNextTurn();
	    
	    for(GameObserver observer : this.gameObservers){
			observer.onGameStart();
		}
	}

	
	/**
     * Deal the cards to all the players
     * @param cards
     */
    public void dealCards( ArrayList<Card> cards, ArrayList<Player> players){
    	
    	Iterator<Card> iter = cards.iterator();
    	
        while(iter.hasNext()){
        	for (Player p : players)
	    	{	
        		if(iter.hasNext()){
	    		 p.addCard(iter.next());
	    		}
	    	}       
        }
        
    }   
    
	public void chooseAnAvatar()
	{
		Stack<Card> characters = new Stack<Card>();//creating a deep copy of an array to modify
		characters.addAll(this.suspectCards);
		
		for(Player player: this.allPlayers)
		{	
		    player.setPlayerCharacter(characters.pop());
		}
	}
	
	
	
	//Major Functions
	public int respondToPlayerInput(int choices)//options are the number of choices
	{
		Scanner userInput = new Scanner(System.in);
		int option = 0;
		boolean badValue =true;
		while (badValue)
		{
			try
			{
				option = userInput.nextInt();
				if(option > choices || option<1)
				{
					throw new Exception();
				}
				badValue = false;
			}
			catch(Exception e)
			{
				System.out.println("Invalid input. Select one of the numbers \n\nPlease try again... \n");
			}
		}
		return option;
	}
	
	public String respondToPlayerStringInput(ArrayList<String>Options)//options are the number of choices
	{
		Scanner userInput = new Scanner(System.in);
		String option = null;
		boolean badValue =true;
		while (badValue)
		{
			try
			{
				option = userInput.nextLine();
				if(Character.isDigit(option.charAt(0))){
					if(Integer.valueOf(option).intValue()>0&&Integer.valueOf(option).intValue()<=Options.size()){
						option = Options.get(Integer.valueOf(option)-1);
					}
				}
				else{
					option.toLowerCase();
				}
				if(option == null || !Options.contains(option) )
				{
					throw new Exception();
				}
				badValue = false;
			}
			catch(Exception e)
			{
				System.out.println("Invalid input. Please type the option name. \n\nPlease try again... \n");
			}
		}
		return option;
	}
	public ArrayList<String> printOptionsMenu(ArrayList<Position>validMoves, Player user)
	{
		ArrayList<String>options = new ArrayList<String>();
		options.add("accuse");
		if(!validMoves.isEmpty()&& !user.getTurnHistory().contains("move")){
			options.add("move");
    	}
    	if(!user.getTurnHistory().contains("suggest")&&!isInHallway(user.getPlayerCharacter().getX(), user.getPlayerCharacter().getY())){
    		options.add("suggest");
    	}
    	if(!user.getTurnHistory().isEmpty()||validMoves.isEmpty()){
    		options.add("pass");
    	}
    	System.out.println("What would you like to do?\n"
    			+ this.printStringArrayValues(options));
    	
    	return options;
	}
	
    /**
     * Gets all the possible moves from a given room
     * @param room
     * @return An ArrayList that contains all the possibles moves for a given room
     */
    public ArrayList<Position> getValidMoves(Position p){
    	
        int posX = p.getX();
        int posY = p.getY();
        System.out.println("Current Position: " + posX + " , " + posY );
        
        ArrayList<Position>validMoves = new ArrayList<Position>();
        
      //Row before selected position.
        if((posY-1) >= 0){
        	 if((posX-1) >= 0){
        		 if(this.boundaryMap[posY-1].charAt(posX-1) == '1'){
        			 //validMoves.add(new Position(posX-1,posY-1));
        		 }
        	 }
             if(this.boundaryMap[posY-1].charAt(posX) == '1'){
             	validMoves.add(new Position(posX,posY-1));
             }
             if((posX+1) <= 6){
            	 if(this.boundaryMap[posY-1].charAt(posX+1) == '1'){
            		 //validMoves.add(new Position(posX+1,posY-1));
            	 }
             }
        }
        //Same row of selected position.
        if(true){
       	 	if((posX-1) >= 0){
       	 		if(this.boundaryMap[posY].charAt(posX-1) == '1'){
       	 			validMoves.add(new Position(posX-1,posY));
       	 		}
       	 	}
            if(this.boundaryMap[posY].charAt(posX) == '1'){
            	validMoves.add(new Position(posX,posY));
            }
            if((posX+1) <= 6){
           	 	if(this.boundaryMap[posY].charAt(posX+1) == '1'){
           	 		validMoves.add(new Position(posX+1,posY));
           	 	}
            }
       }
        //Row after selected position.
        if((posY+1) <= 6){
        	 if((posX-1) >= 0){
        		 if(this.boundaryMap[posY+1].charAt(posX-1) == '1'){
        			 //validMoves.add(new Position(posX-1,posY+1));
        		 }
        	 }
             if(this.boundaryMap[posY+1].charAt(posX) == '1'){
             	validMoves.add(new Position(posX,posY+1));
             }
             if((posX+1) <= 6){
            	 if(this.boundaryMap[posY+1].charAt(posX+1) == '1'){
            		 //validMoves.add(new Position(posX+1,posY+1));
            	 }
             }
        }
        
        if(this.hasSecretPassage(p)){
        		validMoves.add(this.getSecretPassage(p));
        };
        
        return validMoves;
    }
	
	public int confirmAccusation(){
        System.out.println("Make an accusation?");
        System.out.println("1. " + this.yesAndNo.get((0)));
        System.out.println("2. " + this.yesAndNo.get((1)));
                    
        int response = respondToPlayerInput(yesAndNo.size());
        
        return response;
    }
	
	
    public Solution takeTurn(Player player){
        printHeader(player);    	
        
     	ArrayList<Position>validMoves = new ArrayList<Position>();
        Position p = new Position(player.getPlayerCharacter().getX(),player.getPlayerCharacter().getY());
    	validMoves = getValidMoves(p);
     	
		ArrayList<String>choices = printOptionsMenu(validMoves,player);
		String option = this.respondToPlayerStringInput(choices);

                boolean done = false;
                
		Solution value = null;                  
                
                while(!done){
                    if (option.equals("accuse")){
                        if(confirmAccusation() == 2){
                            printOptionsMenu(validMoves,player);
                            option = this.respondToPlayerStringInput(choices);
                        }
                        else{
                            value = accuse();
                            player.getTurnHistory().add("accuse");
                            player.setIsTurn(false);
                            done = true;
                        }
                            
                    }
                    else if(option.equals("move")){
                            move(validMoves,player);
                            player.getTurnHistory().add("move");
                            done = true;
                    }
                    else if(option.equals("suggest")){			
                            value = suggest(p);
                            value.getPerson().updateLocation(p, true);
                            player.getTurnHistory().add("suggest");
                            player.getPlayerCharacter().setMovedHere(false);
                            done = true;
                    }
                    else if(option.equals("pass")){			
                            player.setIsTurn(false);
                            player.getTurnHistory().clear();
                            done = true;
                    }
                }
                    
        return value;
    }
    
	public Solution accuse(){
		Solution value;
		Card _w;
		Card _r;
		Card _s;
		System.out.println("Which weapon\n" + this.printArrayValues(this.weaponCards));
		_w = this.weaponCards.get(this.respondToPlayerInput(6)-1);
		
		ArrayList<Card>OnlyRooms = new ArrayList<Card>(); //We take out hallways to elimiate them as an option
		for(Card room: this.roomCards){						//for choosing
			if(!this.isInHallway(room.getX(), room.getY())){
				OnlyRooms.add(room);
			}
		}
		System.out.println("Which Room\n" + this.printArrayValues(OnlyRooms));
		_r = OnlyRooms.get(this.respondToPlayerInput(9)-1);
		System.out.println("Which Character\n" + this.printArrayValues(this.suspectCards));
		_s = this.suspectCards.get(this.respondToPlayerInput(6)-1);
		value = new Solution( _s, _r,_w);
        value.setAccuse(true);//logic behind accusation requires this boolean update
        
        return value;
	}
	
	public Solution suggest(Position p){
		Solution value;
		Card _w;
		Card _r;
		Card _s;
		System.out.println("Which weapon\n" + this.printArrayValues(this.weaponCards));
		_w = this.weaponCards.get(this.respondToPlayerInput(6)-1);
		_r = findRoomFromPosition(p);
		System.out.println("Which Character\n" + this.printArrayValues(this.suspectCards));
		_s = this.suspectCards.get(this.respondToPlayerInput(6)-1);
		value = new Solution( _s, _r,_w );
		return value;
	}
	
	public void move(ArrayList<Position>validMoves, Player player){
		System.out.println("Please select your requested location:\n" + this.printPositionArrayValues(validMoves));
		int choice = this.respondToPlayerInput(validMoves.size());                  
		player.getPlayerCharacter().updateLocation(validMoves.get(choice-1), true);
	}
	
    public boolean disproveSuggestion(Player curr, Player next, Solution guess){
    	ArrayList<Card>disprovingCards = cardsToShow(next,guess);
    	boolean disproved = false;
    	if(!disprovingCards.isEmpty()){
    		disproved = true;
    		next.displayPopUp("Which card would you like to show " + 
    				next.toString() + " to disprove their suggestion:\n" +
    				printArrayValues(disprovingCards));
    		int choice = this.respondToPlayerInput(disprovingCards.size());
    		curr.displayPopUp(disprovingCards.get(choice-1).toString());
    	}
    	return disproved;
    }
    
	public void printHeader(Player player)
	{
		Card Character = player.getPlayerCharacter();
		Card CurrRoom = findRoomFromPosition(new Position(Character.getX(), Character.getY()));
		if (CurrRoom == null){
			System.out.println("****************************\n"
			        +  "** Player "+ Character.toString() + " MENU **\n"
			        + "** You are in X: " + String.valueOf(Character.getX()) + " Y: " + String.valueOf(Character.getY()) + "     **\n"
			        +  "****************************\n");
		}
		else{
			System.out.println("****************************\n"
	        +  "** Player "+ Character.toString() + " MENU **\n"
	        + "** You are in X: " + String.valueOf(Character.getX()) + " Y: " + String.valueOf(Character.getY()) + "     **\n"
	        + "**   Room " + CurrRoom.toString() + "        **\n"
	        +  "****************************\n");
		}
	}
	
    /**
     * makes a list of possible cards for each player to show to
     * prove a suggestion
     * @param p the current player's hand to check
     * @param s the suggestion 
     * @return 
     */
    public ArrayList<Card> cardsToShow(Player p, Solution s){
        ArrayList<Card>pHand = p.getHand();
        ArrayList<Card>disprovingCards = new ArrayList<Card>();
        if(pHand.contains(s.getPerson())){
        	disprovingCards.add(s.getPerson());
        }
        if(pHand.contains(s.getWeapon())){
        	disprovingCards.add(s.getWeapon());
        }
        if(pHand.contains(s.getPlace())){
        	disprovingCards.add(s.getPlace());
        }

        return disprovingCards;    
    }
    
	public Card findRoomFromPosition(Position p){
		Card room = null;
		for(Card c: this.roomCards){
			if(c.getX()==p.getX()){
				if(c.getY()==p.getY()){
					room = c;
					break;
				}
			}
		}
		return room;
	}
	
	public void notifyAllPlayers(String guess){
		for(Player p : allPlayers)
		{
				p.displayPopUp(guess);
		}
	}
	
	public int nextPlayerIndex(int index){
		int nextPlayer;
		if(	index == allPlayers.size()-1){
			nextPlayer = 0;
		}
		else{
			nextPlayer = index+1;
		}
		return nextPlayer;
	}
	
    /**
     * SecretPassage getter
     * @param room
     * @return the secret passage
     */
    public boolean hasSecretPassage(Position p){
    	boolean hasSecret = false;
    	if(p.getX()==1||p.getX()==5)
    	{
    		if(p.getY()==1||p.getY()==5)
    		{
    			hasSecret = true;
    		}
    	}
       return hasSecret;
    }
    
    public Position getSecretPassage(Position p){
    	Position secretRoom = new Position(1,1);//
    	int x = p.getX();
    	int y = p.getY();
    	if(x==1){
    		secretRoom.setX(5);
    	}
    	else {
    		secretRoom.setX(1);
    	}
    	if(y==5){
    		secretRoom.setY(1);
    	}
    	else{
    		secretRoom.setY(5);
    	}
       return secretRoom;
    }
    
    ArrayList<Position> removeBlockedRooms( ArrayList<Position>validMoves)
    {
    	for(Player player : this.allPlayers)
    	{
    		Position p = new Position (player.getPlayerCharacter().getX(),player.getPlayerCharacter().getY());
    		if(isInHallway(p.getX(),p.getY()))
    		{
    			if(validMoves.contains(p))
    			{
    				validMoves.remove(p);
    			}
    		}
    		
    	}
    	return validMoves;
    }
    
	public boolean isInHallway(int x, int y)
	{
		boolean hallway = false;
		if(x==2||x==4)
		{
			hallway = true;
		}
		if(y==2||y==4)
		{
			hallway = true;
		}
		return hallway;
	}
	
	public boolean isCurrentPlayerOnHallway(){
		return isInHallway(this.getCurrentTurn().getPlayerCharacter().getX(),this.getCurrentTurn().getPlayerCharacter().getY());
	}
	
	public String printArrayValues(ArrayList<Card>array){
		StringBuilder str = new StringBuilder();
		for(int i=0; i<array.size(); i++){
			str.append(String.valueOf(i+1)+ ". " + array.get(i).toString()+"\n");
		}
		return str.toString();
	}
	
	public String printPositionArrayValues(ArrayList<Position>array){
		StringBuilder str = new StringBuilder();
		for(int i=0; i<array.size(); i++){
			str.append(String.valueOf(i+1)+ ". " + array.get(i).toString()+"\n");
		}
		return str.toString();
	}
	
	public String printStringArrayValues(ArrayList<String>array){
		StringBuilder str = new StringBuilder();
		for(int i=0; i<array.size(); i++){
			str.append(String.valueOf(i+1)+ ". " + array.get(i).toString()+"\n");
		}
		return str.toString();
	}
	
	public void initPlayerOptions(Player user){
		/*ArrayList<Position>validMoves = new ArrayList<Position>();
		Position p = new Position (user.getPlayerCharacter().getX(),user.getPlayerCharacter().getY()); 
		validMoves = getValidMoves(p);
     	
		int choices = printOptionsMenu(validMoves, p );*/
	}
	
	/**
	 * Add a player to the game board.
	 * @param player
	 */
	public void addPlayer(Player player) {
		
		System.out.println("Adding player to board game: " +  player.getPlayerName());
		this.allPlayers.add(player);
		
		System.out.println((isGameStarted) ? "Sending board game map update..." : "Game hasn't started.");
		
		if(isGameStarted){
			for(GameObserver observer : this.gameObservers){
				observer.onMapChange();
			}
		}
		
	}
    
    public Player getCurrentTurn(){
    	return this.currentPlayerOnTurn;
    }
    
    public Player getNextTurn(){
    	
    	System.out.println("Getting next player turn.");
    	
    	if(this.getCurrentTurn() != null){
    		System.out.println("Current Player: " + this.currentPlayerOnTurn.getPlayerName());
    		this.currentPlayerOnTurn.resetPlayerTurn();
    		this.playerTurnCollection.add(this.currentPlayerOnTurn);
    	}
    	
    	this.currentPlayerOnTurn = this.playerTurnCollection.remove();
    	System.out.println("Next Player: " + this.currentPlayerOnTurn.getPlayerName());
    	this.currentPlayerOnTurn.initializePlayerTurn();
    	
    	for(GameObserver observer : this.gameObservers){
			observer.onTurnChange();
		}
    	
    	return this.currentPlayerOnTurn;
    }
    
    public Player peekNextTurn(){
    	return this.playerTurnCollection.peek();	
    }

	public void movePlayer(Session session, Position position) {
		
		System.out.println("Player want to move to: " + position.getX() + " : " + position.getY());
		
		Player player = this.getPlayer(session);
		ArrayList<Position> validMovesForPlayer = this.getValidMoves(new Position(player.getPlayerCharacter().getX(),player.getPlayerCharacter().getY()));
		
		System.out.println(validMovesForPlayer.isEmpty() ? "No valid moves available." : "");
		
		for(Position tempPosition : validMovesForPlayer){
			System.out.println(player.getPlayerName() + " - Valid Position: " + tempPosition);
		}
		
		if(validMovesForPlayer.contains(position)){
			System.out.println("Position Updated.");
			
			player.setHasMove(true);
			player.getPlayerCharacter().updateLocation(position, true);
			
			if(this.isCurrentPlayerOnHallway()){
				this.getNextTurn();
			}
			
			for(GameObserver observer : this.gameObservers){
				observer.onPlayerMove();
			}
		}
		else{
			System.out.println("Invalid position.");
		}
		
	}
	
	public Player getPlayer(Session session){
		Player tempPlayer = null;
		for(Player player : this.allPlayers){
			if(player.getId() == session.getId()){
				tempPlayer = player;
				break;
			}
		}
		return tempPlayer;
	}

	public void makeSuggestion(String who, String what, String where) {
		
		System.out.println(this.getCurrentTurn().getPlayerName() + " - Submitted suggestion.");
		
		Card tempCard = null;
		
		Card whereCard = this.findRoomFromPosition(new Position(this.getCurrentTurn().getPlayerCharacter().getX(),
																this.getCurrentTurn().getPlayerCharacter().getY()));
		
		outerloop:
		for(Player player : this.allPlayers){
			if(!this.getCurrentTurn().getId().equals(player.getId())){
				for(Card card : player.getHand()){
					if(card.getName().equals(who) || card.getName().equals(what) || card.getName().equals(whereCard)){
						tempCard = card;
						System.out.println("Found card on " + player.getPlayerName() + " hand of cards.");
						break outerloop;
					}
				}
			}
		}
		
		if(tempCard != null){
			String accusationResponse = "A player has the " + tempCard.getName() + " card.";
			for(GameObserver observer : this.gameObservers){
				observer.onSuggestion(accusationResponse);
			}
		}
		else{
			String accusationResponse = "No player has a card.";
			for(GameObserver observer : this.gameObservers){
				observer.onSuggestion(accusationResponse);
			}
		}
		
		this.getNextTurn();	
		
	}

	public void makeAccusation(String who, String what, String where) {
		
		System.out.println(this.getCurrentTurn().getPlayerName() + " - Submitted accusation.");
		
		Card whereCard = this.findRoomFromPosition(new Position(this.getCurrentTurn().getPlayerCharacter().getX(),
				this.getCurrentTurn().getPlayerCharacter().getY()));

		System.out.println(who + " : " + what + " : " + whereCard.getName());
		
		if(this.answer.getPerson().getName().equals(who) 
			&& this.answer.getWeapon().getName().equals(what) 
			&& this.answer.getPlace().getName().equals(whereCard.getName())){
			String winningMessage = "Player " + this.getCurrentTurn().getPlayerName() + " has won.";
			for(GameObserver observer : this.gameObservers){
				observer.onAccusation(winningMessage);
			}
		}
		else{
			String loserMessage = "Player " + this.getCurrentTurn().getPlayerName() + " has lost.";
			for(GameObserver observer : this.gameObservers){
				observer.onAccusation(loserMessage);
			}
			this.playerTurnCollection.remove(this.currentPlayerOnTurn);
			this.currentPlayerOnTurn = null;
		}
		
		this.getNextTurn();	
		
	}
	
}
