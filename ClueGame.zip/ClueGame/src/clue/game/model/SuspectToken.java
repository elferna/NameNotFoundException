package clue.game.model;

public class SuspectToken {

	public void setLocation(Object xPos, Object yPos) {
		// TODO Auto-generated method stub
		
	}

}
