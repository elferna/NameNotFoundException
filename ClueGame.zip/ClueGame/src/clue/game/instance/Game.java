//Ignore this class. Don't think we need it...

//package clue.game.instance;
//
//import java.util.ArrayList;
//
//import clue.game.model.BoardGame;
//import clue.game.model.Player;
//
//public class Game {
//
//	public static void main(String[] args) 
//	{
//		ArrayList<Player>temp = new ArrayList<Player>();
////		temp.add(new Player("P1"));
////		temp.add(new Player("P2"));
////		temp.add(new Player("P3"));
//		BoardGame BG = new BoardGame(temp,1);
//		BG.initializeGame(temp);
//		BG.play();
//	}
//
//}
