package clue.game;

public class GameUtils {
	
	public static String getPlayerPositionMap(int posX, int posY){
		
		String tempPositionMap = "";
		
		for(int y = 0; y < 7; y++){
			for(int x = 0; x < 7; x++){
				if(x == posX && y == posY){
					tempPositionMap = tempPositionMap + "1";
				}
				else{
					tempPositionMap = tempPositionMap + "0";
				}
			}
		}
		
		System.out.println("Player Position Binary Map: " + tempPositionMap);
		return tempPositionMap;
		
	}

}
