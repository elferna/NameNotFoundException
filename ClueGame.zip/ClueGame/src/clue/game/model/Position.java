package clue.game.model;

public class Position {

	private int x;
	private int y;
	
	public Position(int x, int y) {
		this.x = x;
		this.y = y;
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	
	@Override
	public String toString() {
		
		return "("+String.valueOf(this.x)+","+String.valueOf(this.y)+")";
	}
	
	@Override
	public boolean equals(Object obj) {
		Position position = (Position) obj;
		return this.getX() == position.getX() && this.getY() == position.getY();
	}
}
